Hello! Welcome to my bash script. I will be giviing you instructions on how to run this particular script.
This script takes 11 parameters, so bear with me as I lay them out for you.

The first parameter is the remote server of the file (basically the IP address of the server)
The second parameter is the userid to login to the machine (In my case it is hbounds1)
The third parameter is the remote file path on the remote server (for me it is /home/shared/MOCK_MIX_v2.1.csv.bz2)
The fourth parameter is my gender_edit.awk script (Make sure you include the full file path to the script on your machine - for me it is /home/hbounds/semester_project/gender_edit.awk)
The fifth parameter is my state_edit.awk script
The sixth parameter is my summary.awk script
The seventh parameter is my transaction.awk script
The eighth parameter is my purchase.awk script
The ninth parameter is my transaction_header.awk script
The tenth parameter is my purchase_header.awk script
The eleventh and FINAL parameter is my excpetions.awk script

Thank you for running my script and hopefully with the right steps, it runs correctly for you!!